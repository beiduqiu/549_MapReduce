

# Server = "192.168.1.68"
Server = "192.168.1.146"

def ServerIP():
    return Server